/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.util.ArrayList;
import java.util.List;

import queryrunner.component.QueryParameter;

/**
 *
 * @author mckeem
 */
public class QueryData 
{
	public QueryData(String name, String query, List<QueryParameter> params, boolean isAction)
	{
		this.name = name;
		m_queryString = query;
        if(params != null) {m_arrayParams = params;} 
        else {m_arrayParams = new ArrayList<QueryParameter>();}
        m_isAction = isAction;
        m_isParams = m_arrayParams.size() > 0;
	}
    
    public String getQueryString()
    {
        return m_queryString;
    }
    
    public String getName()
    {
    	return name;
    }
    
    public int getParamAmount()
    {
        if (m_arrayParams == null)
            return 0;
        else
            return m_arrayParams.size();
    }
    
    public List<QueryParameter> getParameters() {
    	return m_arrayParams;
    }
  
    public String getParamText(int index)
    {
        return m_arrayParams.get(index).text;
    }
    
    public boolean getLikeParam(int index)
    {
        return m_arrayParams.get(index).isLike;
    }
    
    public boolean isQueryAction()
    {
        return m_isAction;
    }
    
    public boolean isQueryParam()
    {
        return m_isParams;
    }
     
    private String m_queryString;
    private String name;
    private List<QueryParameter> m_arrayParams;
    private boolean m_isAction;
    private boolean m_isParams;
}
