package queryrunner;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class QueryConsole {
	
	private Scanner inScanner;

    // Query Console Constructor. Driver code for QueryRunner console mode
    public QueryConsole(QueryRunner queryRunner) {
        System.out.println("QueryRunner console application");
        m_queryRunner = queryRunner;
        // db connection StringBuilders
        inScanner = new Scanner(System.in);
        String hostName, hostUsername, hostPassword, hostDatabase;

        // Create DB Connection and connect to DB
        boolean connection;
        do {
            System.out.print("Enter hostName: ");
            hostName = inScanner.nextLine();
            System.out.print("Enter hostUsername: ");
            hostUsername = inScanner.nextLine();
            System.out.print("Enter hostPassword: ");
            hostPassword = inScanner.nextLine();
            System.out.print("Enter hostDatabase: ");
            hostDatabase = inScanner.nextLine();
            connection = m_queryRunner.Connect(hostName, hostUsername, hostPassword, hostDatabase);
            System.out.println("Connecting...");
            if(!connection) {
                System.out.println(ANSI_RED + "ERROR: Could not connect to db. Please try again" + ANSI_RESET);
                System.out.println(ANSI_RED + m_queryRunner.GetError() + ANSI_RESET);
            }
        } while(!connection);

        System.out.println(ANSI_GREEN + "Connection successful!" + ANSI_RESET);

        // QueryRunner console
        String line = "";
        do{
            if(!currentRole.isEmpty())
                System.out.print("\n" + ANSI_CYAN + currentRole + ANSI_RESET + " | QueryRunner> ");
            else
                System.out.print("QueryRunner> ");
            if (inScanner.hasNext()) { line = inScanner.nextLine(); }
        } while(Process(line));
        inScanner.close();

        System.out.println("Thank you for using QueryRunner console!");
    }

    // ANSI Colors for console
    public final String ANSI_RED     = "\u001B[31m";
    public final String ANSI_RESET   = "\u001B[0m";
    public final String ANSI_YELLOW  = "\u001B[33m";
    public final String ANSI_GREEN   = "\u001B[32m";
    public final String ANSI_CYAN	 = "\u001B[36m";
    public final String	ANSI_WHITE	 = "\u001B[37m";

    // Console application variables
    private QueryRunner m_queryRunner;
    private String currentRole = "";

    /**
     * Console application methods
     */

    public void Help() {
        System.out.println("show queries");
        System.out.println("\tshows all the embeddedSQL queries");
        System.out.println("run <query number>");
        System.out.println("\t<query number> query number must be valid, please refer to show queries" +
                " for the range");
        System.out.println("set role <role>");
        System.out.println("\tThe following roles are available for selection:");
        System.out.println("\tCustomer, Staff, Kitchen Manager, Bar Manager, DB Admin");
    }

    public String[] GetCommands(String command) {
        return command.split(" ");
    }

    public void Run(int queryNumber) {
        queryNumber -= 1;
        if (queryNumber >= 0 && queryNumber < m_queryRunner.GetCurrentQueries().size()) {
            String[] paramValues = {};
            // Parameter Query
            if(m_queryRunner.isParameterQuery(queryNumber)) {
                int paramNumbers = m_queryRunner.GetParameterAmtForQuery(queryNumber); // parameter numbers
                System.out.println("This query has " + paramNumbers  + " parameters. Please enter the values of the following parameters:");
                paramValues = new String[paramNumbers];
                for(int i = 0; i < paramNumbers; i++){
                    System.out.print(m_queryRunner.GetParamText(queryNumber, i) + ": ");
                    if (inScanner.hasNext()) { 
                    	String paramInputValue = inScanner.nextLine();
                        paramValues[i] = paramInputValue;
                    }
                }
            }
            //Action Query
            if(m_queryRunner.isActionQuery(queryNumber)) {
                System.out.println("This is an action query");
                try{
                    m_queryRunner.ExecuteUpdate(queryNumber, paramValues);
                    int rowsAffected = m_queryRunner.GetUpdateAmount();
                    System.out.println(rowsAffected + " rows were affected");
                } catch (Exception e) {
                    System.out.println(ANSI_RED + "Query couldn't be executed");
                    System.out.println(m_queryRunner.GetError() + ANSI_RESET);
                }

            }
            //Regular Query
            else {
                System.out.println(ANSI_WHITE + "Executing query..." + ANSI_RESET);
                try {
                    m_queryRunner.ExecuteQuery(queryNumber, paramValues);
                } catch (Exception e) {
                    System.out.println(ANSI_RED + "Query couldn't be executed");
                    System.out.println(m_queryRunner.GetError() + ANSI_RESET);
                }
            }
        } else {
            System.out.println(ANSI_YELLOW + "Query doesn't exist. Run show queries to get a list of queries" + ANSI_RESET);
        }
    }

    // Process lines entered by the user in the console
    public boolean Process(String line) {
        line = line.toLowerCase();

        // Show console documentation
        if (line.equals("help")) {
            Help();
            return true;
        }
        // quit application
        else if (line.equals("quit")) {
            m_queryRunner.Disconnect();
            return false;
        }

        String[] commands = GetCommands(line);
        if (commands.length == 1) { // invalid command entered by user
            System.out.println(ANSI_YELLOW + "Please enter a valid command. Type help to view the documentation."
                    + ANSI_RESET);
        }
        else if (commands.length == 2) { // show & run commands
            if (commands[0].equals("show") && commands[1].equals("queries")) {
                List<QueryData> queries = m_queryRunner.GetCurrentQueries();
                if (queries.isEmpty())
                    System.out.println(ANSI_YELLOW + "Please select a role first." + ANSI_RESET);
                for(int i = 0; i < queries.size(); i++) {
                    System.out.println(i+1 + " " + queries.get(i).getName());
                }
            } else if (commands[0].equals("run")) {
                try {
                    Run(Integer.parseInt(commands[1]));
                } catch (NumberFormatException e) {
                    System.out.println(ANSI_YELLOW + "Please enter a valid query number" + ANSI_RESET);
                }

            } else {
                System.out.println(ANSI_RED + "Unidentified command. Please refer to help." + ANSI_RESET);
            }
        } else if(commands.length >= 3 && ( commands[0].equals("set") && commands[1].equals("role") )) { // select role command
            // pre defined valid roles
            String[] validRoles = {"customer", "staff", "kitchenmanager", "barmanager", "dbadmin"};
            List<String> validRolesList = Arrays.asList(validRoles);
            // get the role string from the user input
            StringBuilder roleStringBuilder = new StringBuilder();
            for(int i = 2; i < commands.length; i++) {
                roleStringBuilder.append(commands[i]);
            }
            String role = roleStringBuilder.toString();

            // validate role
            if(validRolesList.contains(role)) {
                m_queryRunner.setRole(role);
                currentRole = role;
            } else {
                System.out.println(ANSI_YELLOW + "Invalid role entered. Please enter a valid role" + ANSI_RESET);
                currentRole = "";
            }
        }
        // Invalid entry from the user
        else {
            System.out.println(ANSI_RED + "Unidentified command. Please refer to help." + ANSI_RESET);
        }

        return true;
    }


    // End console application methods
}
