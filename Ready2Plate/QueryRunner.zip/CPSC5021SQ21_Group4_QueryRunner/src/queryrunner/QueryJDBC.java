/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

import net.efabrika.util.DBTablePrinter;
import queryrunner.component.QueryParameter;

/**
 *
 * @author mckeem
 */
public class QueryJDBC
{
    static final String DB_DRV = "com.mysql.cj.jdbc.Driver";

    private Connection m_conn = null;
    private String m_error = "";
    private String[] m_headers;
    private String[][] m_allRows;
    private int m_updateAmount = 0;
    private boolean console;

    public QueryJDBC(boolean console)
    {
        m_updateAmount = 0;
        this.console = console;
    }

    public String GetError()
    {
        return m_error;
    }


    public String[] GetHeaders()
    {
        return this.m_headers;
    }

    public String[][] GetData()
    {
        return this.m_allRows;
    }

    public int GetUpdateCount()
    {
        return m_updateAmount;
    }

    // We think we can always setString on Parameters. Not sure
    // if this is true.
    // GetString on Results is fine though

    public boolean ExecuteQuery(String szQuery, String[] args, List<QueryParameter> params)
    {
        // Try to get the columns and the amount of columns
        try
        {
            PreparedStatement preparedStatement = this.m_conn.prepareStatement(szQuery);

            int nParamAmount = params.size();

            for (int i=0; i < nParamAmount; i++)
            {
                if (params.get(i).isLike)
                {
                    args[i] += "%";
                }
                if (params.get(i).isInteger)
                {
                    preparedStatement.setInt(i + 1, Integer.parseInt(args[i]));
                }
                else if (params.get(i).isDate)
                {
                    preparedStatement.setDate(i+1, Date.valueOf(args[i]));
                }
                else
                {
                    preparedStatement.setString(i + 1, args[i]);
                }
            }
            ResultSet resultSet = preparedStatement.executeQuery();
            m_updateAmount = 0;
            processResults(resultSet);
            resultSet.close();
            preparedStatement.close();
        }
        catch (SQLException ex)
        {
            setErrorMessage(ex);

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return false;

        }
        return true;
    }

    public void processResults(ResultSet resultSet) throws SQLException
    {
        ResultSetMetaData rsmd = resultSet.getMetaData();
        if (console) { DBTablePrinter.printResultSet(resultSet); }
        int nColAmt = rsmd.getColumnCount();
        m_headers = new String [nColAmt];

        for (int i=0; i< nColAmt; i++)
        {
            m_headers[i] = rsmd.getColumnLabel(i+1);
        }

        int amtRow = 0;
        while(resultSet.next()){
            amtRow++;
        }
        if (amtRow > 0)
        {
            this.m_allRows= new String[amtRow][nColAmt];
            resultSet.beforeFirst();
            int nCurRow = 0;
            while(resultSet.next())
            {
                for (int i=0; i < nColAmt; i++)
                {
                    m_allRows[nCurRow][i] = resultSet.getString(i+1);
                }
                nCurRow++;
            }
        }
        else
        {
            this.m_allRows= new String [1][nColAmt];
            for (int i=0; i < nColAmt; i++)
            {
                m_allRows[0][i] = "";
            }
        }
    }

    public boolean ExecuteUpdate(String szQuery, String[] args)
    {
        m_updateAmount=0;
        // Try to get the columns and the amount of columns
        try
        {

            PreparedStatement preparedStatement = this.m_conn.prepareStatement(szQuery);

            int nParamAmount = args.length;

            for (int i = 0; i < nParamAmount; i++)
            {
                preparedStatement.setString(i+1, args[i]);
            }

            m_updateAmount = preparedStatement.executeUpdate();
            preparedStatement.close();
        }

        catch (SQLException ex)
        {
            setErrorMessage(ex);

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return false;

        }

        return true;
    }



    public boolean ConnectToDatabase(String host, String user, String pass, String database)
    {
        String url;

        url = "jdbc:mysql://";
        url += host;
        url += ":3306/";
        url += database;
        url +="?autoReconnect=true&useSSL=false";
        try
        {
            Class.forName(DB_DRV).getDeclaredConstructor().newInstance();
            m_conn = DriverManager.getConnection(url,user,pass);
        }
        catch (SQLException ex)
        {
            setErrorMessage(ex);
            return false;
        }
        catch (Exception ex)
        {
            // handle the error
            m_error = "SQLException: " + ex.getMessage();
            return false;
        }

        return true;
    }


    /* Document this function
    // TODO    
    */
    public boolean CloseDatabase()
    {
        try
        {
            m_conn.close();
        }
        catch (SQLException ex)
        {
            setErrorMessage(ex);
            return false;
        }
        catch (Exception ex)
        {
            m_error = "Error was " + ex.toString();
            return false;
        }
        return true;
    }

    private void setErrorMessage(SQLException ex)
    {
        m_error = "SQLException: " + ex.getMessage() +
                "\nSQLState: " + ex.getSQLState() +
                "\nErrorCode: " + ex.getErrorCode();
    }
}
