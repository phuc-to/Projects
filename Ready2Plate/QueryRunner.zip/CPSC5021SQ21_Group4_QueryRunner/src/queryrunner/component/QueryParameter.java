package queryrunner.component;

public class QueryParameter {
	
	public String text;
	public boolean isLike;
	public boolean isInteger;
	public boolean isDate;

	public QueryParameter(String text, boolean isLike, boolean isInteger, boolean isDate) {
		this.text = text;
		this.isLike = isLike;
		this.isInteger = isInteger;
		this.isDate = isDate;
	}

}
