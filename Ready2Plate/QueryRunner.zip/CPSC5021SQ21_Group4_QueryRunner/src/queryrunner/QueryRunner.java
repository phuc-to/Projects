/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.util.ArrayList;
import java.util.List;

import queryrunner.io.QueryReader;

/**
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {

    public QueryRunner(boolean console) {
        this.m_jdbcData = new QueryJDBC(console);
        m_updateAmount = 0;
        m_queryListCustomer = QueryReader.getCustomerQueries();
        m_queryListStaff = QueryReader.getStaffQueries();
        m_queryListKManager = QueryReader.getKManagerQueries();
        m_queryListBManager = QueryReader.getBManagerQueries();
        m_queryListDBAdmin = QueryReader.getDBAdminQueries();
        m_queryListEmpty = new ArrayList<QueryData>();
        m_queryListCurrent = m_queryListEmpty;
        m_error = "";
    }

    public List<QueryData> GetCurrentQueries() {
        return m_queryListCurrent;
    }

    public int GetParameterAmtForQuery(int queryChoice) {
        QueryData e = m_queryListCurrent.get(queryChoice);
        return e.getParamAmount();
    }

    public String GetParamText(int queryChoice, int paramnum) {
        QueryData e = m_queryListCurrent.get(queryChoice);
        return e.getParamText(paramnum);
    }

    public String GetQueryText(int queryChoice) {
        QueryData e = m_queryListCurrent.get(queryChoice);
        return e.getQueryString();
    }

    /**
     * Function will return how many rows were updated as a result
     * of the update query
     *
     * @return Returns how many rows were updated
     */

    public int GetUpdateAmount() {
        return m_updateAmount;
    }

    /**
     * Function will return ALL of the Column Headers from the query
     *
     * @return Returns array of column headers
     */
    public String[] GetQueryHeaders() {
        return m_jdbcData.GetHeaders();
    }

    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     *
     * @return multi-dimensional array of String data based on the resultset
     * from the query
     */
    public String[][] GetQueryData() {
        return m_jdbcData.GetData();
    }
    
    public boolean isActionQuery(int queryChoice)
    {
        QueryData e = m_queryListCurrent.get(queryChoice);
        return e.isQueryAction();
    }

    public boolean isParameterQuery(int queryChoice) {
        QueryData e = m_queryListCurrent.get(queryChoice);
        return e.isQueryParam();
    }
    
    public boolean ExecuteQuery(int queryChoice, String[] args)
    {
        QueryData e = m_queryListCurrent.get(queryChoice);        
        boolean bOK = m_jdbcData.ExecuteQuery(e.getQueryString(), args, e.getParameters());
    	m_updateAmount = m_jdbcData.GetUpdateCount();
        if (! bOK) {m_error = m_jdbcData.GetError();}
        return bOK;
    }

    public boolean ExecuteUpdate(int queryChoice, String[] args) {
        QueryData e = m_queryListCurrent.get(queryChoice);
        boolean bOK = m_jdbcData.ExecuteUpdate(e.getQueryString(), args);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        if (!bOK) {
            m_error = m_jdbcData.GetError();
        }
        return bOK;
    }

    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase) {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (!bConnect) {
            m_error = m_jdbcData.GetError();
        }
        return bConnect;
    }

    public boolean Disconnect() {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (!bConnect) {
            m_error = m_jdbcData.GetError();
        }
        return true;
    }

    public String GetError() {
        return m_error;
    }

    public void setRole(String role) {
        if (role.equals("Customer") || role.equals("customer")) {
            m_queryListCurrent = m_queryListCustomer;
        } else if (role.equals("Staff") || role.equals("staff")) {
            m_queryListCurrent = m_queryListStaff;
        } else if (role.equals("Kitchen Manager") || role.equals("kitchenmanager")) {
            m_queryListCurrent = m_queryListKManager;
        } else if (role.equals("Bar Manager") || role.equals("barmanager")) {
            m_queryListCurrent = m_queryListBManager;
        } else if (role.equals("DB Admin") || role.equals("dbadmin")) {
            m_queryListCurrent = m_queryListDBAdmin;
        } else {
            m_queryListCurrent = m_queryListEmpty;
        }
    }

    private QueryJDBC m_jdbcData;
    private String m_error;
    private List<QueryData> m_queryListCustomer;
    private List<QueryData> m_queryListStaff;
    private List<QueryData> m_queryListKManager;
    private List<QueryData> m_queryListBManager;
    private List<QueryData> m_queryListDBAdmin;
    private List<QueryData> m_queryListEmpty;
    private List<QueryData> m_queryListCurrent;
    private int m_updateAmount;



    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        

        if (args.length == 0) {
        	final QueryRunner queryrunner = new QueryRunner(false);
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    new QueryFrame(queryrunner).setVisible(true);
                }
            });
        } else {

            // Complete QueryConsole based on the pseudo-code provided with the original code base
            if (args[0].equals("-console")) {
            	final QueryRunner queryrunner = new QueryRunner(true);
                java.awt.EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        new QueryConsole(queryrunner);
                    }
                });

            }
        }
    }
}
