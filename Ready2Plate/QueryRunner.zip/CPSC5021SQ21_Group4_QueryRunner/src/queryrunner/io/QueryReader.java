package queryrunner.io;

import java.util.ArrayList;
import java.util.List;

import queryrunner.QueryData;
import queryrunner.component.QueryParameter;

public class QueryReader
{
	private static String filepathCustomer = "src/queryrunner/io/input/customer_queries.txt";
	private static String filepathStaff = "src/queryrunner/io/input/staff_queries.txt";
	private static String filepathKManager = "src/queryrunner/io/input/kmanager_queries.txt";
	private static String filepathBManager = "src/queryrunner/io/input/bmanager_queries.txt";
	private static String filepathDBAdmin = "src/queryrunner/io/input/dbadmin_queries.txt";
	
	public static List<QueryData> getCustomerQueries() {
		return getQueries(filepathCustomer);
	}
	
	public static List<QueryData> getStaffQueries() {
		return getQueries(filepathStaff);
	}
	
	public static List<QueryData> getKManagerQueries() {
		return getQueries(filepathKManager);
	}
	
	public static List<QueryData> getBManagerQueries() {
		return getQueries(filepathBManager);
	}
	
	public static List<QueryData> getDBAdminQueries() {
		return getQueries(filepathDBAdmin);
	}
	
	private static List<QueryData> getQueries(String filepath) 
	{
		String filetext = new File_Accesser(filepath).readFile();
		String[] querytext = filetext.split(";");
		for (int i = 0; i < querytext.length; i++) {
			querytext[i] = querytext[i].trim().toLowerCase();
			querytext[i] += ";";
		}
		List<QueryData> queries = new ArrayList<QueryData>();
		for (int i = 0; i < querytext.length; i++) {
			if (! querytext[i].isEmpty()) {
				String name = parseName(querytext[i]);
				if (! name.equals("unnamed query")) {querytext[i] = querytext[i].substring(querytext[i].indexOf('\n') + 1).trim();}
				queries.add(makeQueryData(name, querytext[i], isAction(querytext[i])));
			}
		}
		return queries;
	}
	
	private static String parseName(String query) {
		if(query.charAt(0) == '-'
			&& query.charAt(1) == '-'
			&& query.charAt(2) == ' ') {
			return query.substring(3, query.indexOf('\n'));
		}
		return "unnamed query";
	}
	
	private static QueryData makeQueryData(String name, String query, boolean isAction) 
	{
		List<QueryParameter> params = new ArrayList<QueryParameter>();
		for (int i = 0; i < query.length(); i++) 
		{
			if (query.charAt(i) == '?') {
				boolean isLike = isLike(query, i - 1);
				boolean isInteger = false, isDate = false;
				if(query.charAt(i + 1) == '%') {
					isInteger = query.charAt(i + 2) == 'i';
					isDate = query.charAt(i + 2) == 'd';
					i += 2;
				}
				String paramName = readParamName(query, i + 1);
				params.add(new QueryParameter(paramName, isLike, isInteger, isDate));
				isLike = false;
				i += paramName.length() + 2;
			}
		}
		String queryText = stripParamNames(query);
		return new QueryData(name, queryText.toString(), params, isAction);
	}
	
	private static boolean isAction(String query) {
		int i = 0;
		while (Character.isLetter(query.charAt(i))) {
			i++;
		}
		String firstCommand = query.substring(0, i);
		if (firstCommand.equals("call")) {
			firstCommand = readParamName(query, 4);
		}
		return firstCommand.equals("insert")
				|| firstCommand.equals("update")
				|| firstCommand.equals("delete")
				|| firstCommand.equals("create")
				|| firstCommand.equals("drop")
				|| firstCommand.equals("alter");
	}
	
	private static boolean isLike(String query, int i) {
		while (query.charAt(i) == ' ' || query.charAt(i) == '\t') {
			i--;
		}
		return query.charAt(i - 3) == 'l'
				&& query.charAt(i - 2) == 'i'
				&& query.charAt(i - 1) == 'k' 
				&& query.charAt(i) == 'e';
	}
	
	private static String readParamName(String query, int i) {
		while (query.charAt(i) != '[') {i++;}
		int j = i;
		while (query.charAt(j) != ']') {j++;}
		return query.substring(i + 1, j);
	}
	
	private static String stripParamNames(String query) {
		StringBuilder queryText = new StringBuilder();
		boolean copying = true;
		for (int m = 0; m < query.length(); m++) {
			char c = query.charAt(m);
			if (c == '%' || c == '[') {
				copying = false;
			}
			if (copying) {
				queryText.append(c);
			}
			if (c == ']') {
				copying = true;
			}
		}
		return queryText.toString();
	}
}
